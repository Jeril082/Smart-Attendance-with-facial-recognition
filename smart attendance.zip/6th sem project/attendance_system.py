import cv2
import numpy as np
import face_recognition
import os
from datetime import datetime
import pandas as pd

# Load known images
path = 'known_faces'
images = []
classNames = []

# Load each image and get the student names
for filename in os.listdir(path):
    img = cv2.imread(f'{path}/{filename}')
    images.append(img)
    classNames.append(os.path.splitext(filename)[0])  # remove .jpg

# Encode faces
def findEncodings(images):
    encodeList = []
    for img in images:
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        encode = face_recognition.face_encodings(img)
        if encode:
            encodeList.append(encode[0])
    return encodeList

encodeListKnown = findEncodings(images)
print('Encoding complete!')

# Attendance CSV
def markAttendance(name):
    try:
        df = pd.read_csv('attendance.csv')
    except FileNotFoundError:
        df = pd.DataFrame(columns=["Name", "Time"])

    if name not in df["Name"].values:
        now = datetime.now()
        dtString = now.strftime('%H:%M:%S')
        df = df.append({"Name": name, "Time": dtString}, ignore_index=True)
        df.to_csv('attendance.csv', index=False)
        print(f"{name} marked present at {dtString}")

# Start webcam
cap = cv2.VideoCapture(0)

while True:
    success, img = cap.read()
    smallImg = cv2.resize(img, (0, 0), fx=0.25, fy=0.25)
    smallImg = cv2.cvtColor(smallImg, cv2.COLOR_BGR2RGB)

    facesCurFrame = face_recognition.face_locations(smallImg)
    encodesCurFrame = face_recognition.face_encodings(smallImg, facesCurFrame)

    for encodeFace, faceLoc in zip(encodesCurFrame, facesCurFrame):
        matches = face_recognition.compare_faces(encodeListKnown, encodeFace)
        faceDis = face_recognition.face_distance(encodeListKnown, encodeFace)
        matchIndex = np.argmin(faceDis)

        if matches[matchIndex]:
            name = classNames[matchIndex].upper()
            y1, x2, y2, x1 = faceLoc
            y1, x2, y2, x1 = y1*4, x2*4, y2*4, x1*4
            cv2.rectangle(img, (x1, y1), (x2, y2), (0, 255, 0), 2)
            cv2.putText(img, name, (x1 + 6, y2 + 25), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            markAttendance(name)

    cv2.imshow('Webcam', img)
    if cv2.waitKey(1) == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
